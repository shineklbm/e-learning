jQuery(document).ready(function($){

	$('#accordion > .panel').on('show.bs.collapse', function (e) {
    	$(this).find('.panel-heading').addClass("active-panel");
	});
	$('#accordion > .panel').on('hide.bs.collapse', function (e) {
    	$(this).find('.panel-heading').removeClass("active-panel active");
	});
});