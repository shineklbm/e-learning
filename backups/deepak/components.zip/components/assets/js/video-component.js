jQuery(document).ready(function($){

	// MediaElement('player1', {success: function(me) {
	
	// 	//me.play();
		
	// 	me.addEventListener('timeupdate', function() {
	// 		document.getElementById('time').innerHTML = me.currentTime;
	// 	}, false);
		
	// 	document.getElementById('pp')['onclick'] = function() {
	// 		if (me.paused)
	// 			me.play();
	// 		else
	// 			me.pause();
	// 	};

	// }});
	// $('video').mediaelementplayer({
	// 	alwaysShowControls: false
	// });
});