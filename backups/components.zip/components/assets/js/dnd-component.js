  jQuery(document).ready(function(){
    // $( ".draggable").draggable();

    // $( ".droppable" ).droppable({
    //   drop: function( event, ui ) {
    //   $( '.droppable' ).data( 'hover', 0 );
    //   $( this )
    //   .addClass( "ui-state-highlight" )
    //   .find( "p" )
    //   .html( "Dropped!" );
    //   }
    // });
    // var currentParent;
   
    //     $(".draggable").resizable({
    //         containment: "parent"
    //     }).draggable({
    //         revert: 'invalid',
    //         start: function(){
    //             currentParent = $(this).parent().attr('id');
    //         }
    //     });
            
    //          $(' #dragable-area, .droppable').droppable({
    //     accept:'.draggable',
    //     drop: function(event,ui){
    //         if (currentParent != $(this).attr('id')){
    //           $(ui.draggable).appendTo($(this)).removeAttr('style');
    //         }
    //     }
    // }); 
    // $('#main_list,ul').sortable({
    //     placeholder: 'placeholder',
    //     connectWith: '.connect_lists',
    //     receive: function(event, ui) {
    //         var $this = $(this);
    //         if ($this.children('li').length > 1 && $this.attr('id') != "main_list") {
    //             console.log('Only one per list!');
    //             $(ui.sender).sortable('cancel');
    //         }
    //     }
    // });
    $('.ui-widget-content').sortable({
        placeholder: 'placeholder',
        connectWith: '.connect_lists',
        receive: function(event, ui) {
            var $this = $(this);
            if ($this.children('div').length > 1 && $this.attr('id') != "draggable") {
                console.log('Only one per list!');
                $(ui.sender).sortable('cancel');
            }
        }
    });

  });