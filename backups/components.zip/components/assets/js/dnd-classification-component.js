jQuery(document).ready(function(){
        // $( ".draggable" ).draggable();
        // $( ".droppable" ).droppable({
        //     accept: "#draggable",
        //     activeClass: "ui-state-hover",
        //     hoverClass: "ui-state-active",
        //     drop: function( event, ui ) {
        //         $( this )
        //         .addClass( "ui-state-highlight" )
        //         .find( "p" )
        //         .html( "Dropped!" );
        //     }
        // });

            
                // $('.draggable').draggable( {
                //   containment: '#right-droppable',
                //   revert: 'valid'
                // } );

                // $('.droppable').data( 'number', 1 ).droppable( {
                //   accept: '#right-droppable',
                //   hoverClass: 'hovered',
                //   drop: handleCardDrop
                // } );
 var currentParent;
   
        $(".draggable").resizable({
            containment: "parent"
        }).draggable({
            revert: 'invalid',
            start: function(){
                currentParent = $(this).parent().attr('id');
            }
        });
            
             $(' #right-dnd, .droppable').droppable({
        accept:'.draggable',
        drop: function(event,ui){
            if (currentParent != $(this).attr('class')){
              $(ui.draggable).appendTo($(this)).removeAttr('style');
            }
        }
    });    
    });
