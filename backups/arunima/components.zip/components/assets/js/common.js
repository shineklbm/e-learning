jQuery(document).ready(function(){
	$('.v-scroll').mCustomScrollbar({ theme:"light-1", scrollbarPosition: "outside" });
		
});